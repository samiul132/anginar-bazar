(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,73375,e=>{"use strict";let t=(0,e.i(75254).default)("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);e.s(["ChevronLeft",()=>t],73375)},35933,e=>{"use strict";var t=e.i(43476),s=e.i(57688),r=e.i(22016),a=e.i(73021),i=e.i(95695);function o({product:e}){let{addToCart:o,getItemQuantity:l,updateQuantity:n}=(0,a.useCart)(),c=l(e.id),d=parseFloat(e.sale_price||"0"),u=parseFloat(e.promotional_price||"0"),p=u>0&&u<d,x=p?u:d,m=p?Math.round((d-u)/d*100):0;return(0,t.jsxs)("div",{className:"bg-white rounded-lg overflow-hidden border border-gray-200 hover:shadow-lg transition-all duration-300 flex flex-col h-full",children:[(0,t.jsxs)(r.default,{href:`/product/${e.slug}`,className:"relative aspect-square block",children:[(0,t.jsx)(s.default,{src:(0,i.getImageUrl)(e.image),alt:e.product_name||"Product",fill:!0,className:"object-cover",sizes:"(max-width: 640px) 50vw, (max-width: 768px) 33vw, (max-width: 1024px) 25vw, 20vw"}),p&&(0,t.jsx)("div",{className:"absolute top-2 left-2 z-10",children:(0,t.jsxs)("svg",{width:"40",height:"56",viewBox:"0 0 48 56",xmlns:"http://www.w3.org/2000/svg",children:[(0,t.jsx)("rect",{x:"0",y:"0",width:"48",height:"48",fill:"#DC2626"}),(0,t.jsx)("path",{d:"M 0 48 L 4 56 L 8 48 L 12 56 L 16 48 L 20 56 L 24 48 L 28 56 L 32 48 L 36 56 L 40 48 L 44 56 L 48 48 Z",fill:"#DC2626"}),(0,t.jsxs)("text",{x:"24",y:"20",textAnchor:"middle",fill:"white",fontSize:"18",fontWeight:"bold",fontFamily:"Arial, sans-serif",children:[m,"%"]}),(0,t.jsx)("text",{x:"24",y:"36",textAnchor:"middle",fill:"white",fontSize:"11",fontWeight:"bold",fontFamily:"Arial, sans-serif",children:"OFF"})]})})]}),(0,t.jsxs)("div",{className:"p-3 flex flex-col flex-1",children:[(0,t.jsx)(r.default,{href:`/product/${e.slug}`,className:"font-medium text-sm text-gray-900 mb-2 block h-[40px] overflow-hidden",style:{display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical",overflow:"hidden"},children:e.product_name}),(0,t.jsxs)("div",{className:"flex items-center gap-2 mb-3 min-h-[28px]",children:[p&&(0,t.jsxs)("span",{className:"text-gray-400 line-through text-sm",children:["৳",Math.round(d)]}),(0,t.jsxs)("span",{className:"text-gray-900 font-bold text-lg",children:["৳",Math.round(x)]})]}),(0,t.jsx)("div",{className:"flex-grow"}),0===c?(0,t.jsxs)("button",{onClick:()=>{o({product_id:e.id,name:e.product_name,price:x,image:e.image,slug:e.slug||""},1)},className:"w-full bg-[#FF5533] hover:bg-[#e64e27] text-white font-bold py-2 px-3 rounded-full transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer active:scale-95 text-sm whitespace-nowrap",children:[(0,t.jsx)("svg",{className:"w-4 h-4 flex-shrink-0",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:1.5,d:"M12 4v16m8-8H4"})}),(0,t.jsx)("span",{children:"Add to Cart"})]}):(0,t.jsxs)("div",{className:"flex items-center w-full bg-[#FF5533] rounded-full overflow-hidden text-white text-sm font-bold",children:[(0,t.jsx)("button",{onClick:()=>n(e.id,c-1),className:"flex-1 flex justify-center items-center hover:bg-[#e64e27] transition-colors cursor-pointer py-2",children:(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M20 12H4"})})}),(0,t.jsx)("span",{className:"flex-1 flex justify-center items-center border-x border-white py-2",children:c}),(0,t.jsx)("button",{onClick:()=>n(e.id,c+1),className:"flex-1 flex justify-center items-center hover:bg-[#e64e27] transition-colors cursor-pointer py-2",children:(0,t.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 4v16m8-8H4"})})})]})]})]})}e.s(["default",()=>o])},7233,e=>{"use strict";let t=(0,e.i(75254).default)("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);e.s(["Plus",()=>t],7233)},7823,e=>{"use strict";let t,s;var r,a=e.i(43476),i=e.i(37902),o=e.i(71645),l=e.i(18566),n=e.i(57688),c=e.i(22016),d=e.i(73375),u=e.i(63059),p=e.i(75254);let x=(0,p.default)("minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);var m=e.i(7233);let h=(0,p.default)("share-2",[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]]);var f=e.i(1928),g=e.i(95695),b=e.i(73021),y=e.i(35933),j=e.i(80401);e.i(41983);var v=e.i(79053);let w={data:""},N=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,k=/\/\*[^]*?\*\/|  +/g,C=/\n+/g,F=(e,t)=>{let s="",r="",a="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?s=i+" "+o+";":r+="f"==i[1]?F(o,i):i+"{"+F(o,"k"==i[1]?"":t)+"}":"object"==typeof o?r+=F(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),a+=F.p?F.p(i,o):i+":"+o+";")}return s+(t&&a?t+"{"+a+"}":a)+r},_={},L=e=>{if("object"==typeof e){let t="";for(let s in e)t+=s+L(e[s]);return t}return e};function E(e){let t,s,r=this||{},a=e.call?e(r.p):e;return((e,t,s,r,a)=>{var i;let o=L(e),l=_[o]||(_[o]=(e=>{let t=0,s=11;for(;t<e.length;)s=101*s+e.charCodeAt(t++)>>>0;return"go"+s})(o));if(!_[l]){let t=o!==e?e:(e=>{let t,s,r=[{}];for(;t=N.exec(e.replace(k,""));)t[4]?r.shift():t[3]?(s=t[3].replace(C," ").trim(),r.unshift(r[0][s]=r[0][s]||{})):r[0][t[1]]=t[2].replace(C," ").trim();return r[0]})(e);_[l]=F(a?{["@keyframes "+l]:t}:t,s?"":"."+l)}let n=s&&_.g?_.g:null;return s&&(_.g=_[l]),i=_[l],n?t.data=t.data.replace(n,i):-1===t.data.indexOf(i)&&(t.data=r?i+t.data:t.data+i),l})(a.unshift?a.raw?(t=[].slice.call(arguments,1),s=r.p,a.reduce((e,r,a)=>{let i=t[a];if(i&&i.call){let e=i(s),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":F(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"")):a.reduce((e,t)=>Object.assign(e,t&&t.call?t(r.p):t),{}):a,(e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||w})(r.target),r.g,r.o,r.k)}E.bind({g:1});let P,z,$,S=E.bind({k:1});function M(e,t){let s=this||{};return function(){let r=arguments;function a(i,o){let l=Object.assign({},i),n=l.className||a.className;s.p=Object.assign({theme:z&&z()},l),s.o=/ *go\d+/.test(n),l.className=E.apply(s,r)+(n?" "+n:""),t&&(l.ref=o);let c=e;return e[0]&&(c=l.as||e,delete l.as),$&&c[0]&&$(l),P(c,l)}return t?t(a):a}}var O=(e,t)=>"function"==typeof e?e(t):e,A=(t=0,()=>(++t).toString()),D=()=>{if(void 0===s&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");s=!e||e.matches}return s},B="default",I=(e,t)=>{let{toastLimit:s}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,s)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return I(e,{type:+!!e.toasts.find(e=>e.id===r.id),toast:r});case 3:let{toastId:a}=t;return{...e,toasts:e.toasts.map(e=>e.id===a||void 0===a?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},T=[],R={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},H={},W=(e,t=B)=>{H[t]=I(H[t]||R,e),T.forEach(([e,s])=>{e===t&&s(H[t])})},U=e=>Object.keys(H).forEach(t=>W(e,t)),q=(e=B)=>t=>{W(t,e)},V={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},Z=e=>(t,s)=>{let r,a=((e,t="blank",s)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...s,id:(null==s?void 0:s.id)||A()}))(t,e,s);return q(a.toasterId||(r=a.id,Object.keys(H).find(e=>H[e].toasts.some(e=>e.id===r))))({type:2,toast:a}),a.id},K=(e,t)=>Z("blank")(e,t);K.error=Z("error"),K.success=Z("success"),K.loading=Z("loading"),K.custom=Z("custom"),K.dismiss=(e,t)=>{let s={type:3,toastId:e};t?q(t)(s):U(s)},K.dismissAll=e=>K.dismiss(void 0,e),K.remove=(e,t)=>{let s={type:4,toastId:e};t?q(t)(s):U(s)},K.removeAll=e=>K.remove(void 0,e),K.promise=(e,t,s)=>{let r=K.loading(t.loading,{...s,...null==s?void 0:s.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let a=t.success?O(t.success,e):void 0;return a?K.success(a,{id:r,...s,...null==s?void 0:s.success}):K.dismiss(r),e}).catch(e=>{let a=t.error?O(t.error,e):void 0;a?K.error(a,{id:r,...s,...null==s?void 0:s.error}):K.dismiss(r)}),e};var Y=1e3,X=S`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,G=S`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,J=S`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,Q=M("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${X} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${G} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${J} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,ee=S`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,et=M("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${ee} 1s linear infinite;
`,es=S`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,er=S`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,ea=M("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${es} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${er} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ei=M("div")`
  position: absolute;
`,eo=M("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,el=S`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,en=M("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${el} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,ec=({toast:e})=>{let{icon:t,type:s,iconTheme:r}=e;return void 0!==t?"string"==typeof t?o.createElement(en,null,t):t:"blank"===s?null:o.createElement(eo,null,o.createElement(et,{...r}),"loading"!==s&&o.createElement(ei,null,"error"===s?o.createElement(Q,{...r}):o.createElement(ea,{...r})))},ed=M("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,eu=M("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ep=o.memo(({toast:e,position:t,style:s,children:r})=>{let a=e.height?((e,t)=>{let s=e.includes("top")?1:-1,[r,a]=D()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*s}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*s}%,-1px) scale(.6); opacity:0;}
`];return{animation:t?`${S(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${S(a)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},i=o.createElement(ec,{toast:e}),l=o.createElement(eu,{...e.ariaProps},O(e.message,e));return o.createElement(ed,{className:e.className,style:{...a,...s,...e.style}},"function"==typeof r?r({icon:i,message:l}):o.createElement(o.Fragment,null,i,l))});r=o.createElement,F.p=void 0,P=r,z=void 0,$=void 0;var ex=({id:e,className:t,style:s,onHeightUpdate:r,children:a})=>{let i=o.useCallback(t=>{if(t){let s=()=>{r(e,t.getBoundingClientRect().height)};s(),new MutationObserver(s).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return o.createElement("div",{ref:i,className:t,style:s},a)},em=E`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,eh=({reverseOrder:e,position:t="top-center",toastOptions:s,gutter:r,children:a,toasterId:i,containerStyle:l,containerClassName:n})=>{let{toasts:c,handlers:d}=((e,t="default")=>{let{toasts:s,pausedAt:r}=((e={},t=B)=>{let[s,r]=(0,o.useState)(H[t]||R),a=(0,o.useRef)(H[t]);(0,o.useEffect)(()=>(a.current!==H[t]&&r(H[t]),T.push([t,r]),()=>{let e=T.findIndex(([e])=>e===t);e>-1&&T.splice(e,1)}),[t]);let i=s.toasts.map(t=>{var s,r,a;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(s=e[t.type])?void 0:s.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(r=e[t.type])?void 0:r.duration)||(null==e?void 0:e.duration)||V[t.type],style:{...e.style,...null==(a=e[t.type])?void 0:a.style,...t.style}}});return{...s,toasts:i}})(e,t),a=(0,o.useRef)(new Map).current,i=(0,o.useCallback)((e,t=Y)=>{if(a.has(e))return;let s=setTimeout(()=>{a.delete(e),l({type:4,toastId:e})},t);a.set(e,s)},[]);(0,o.useEffect)(()=>{if(r)return;let e=Date.now(),a=s.map(s=>{if(s.duration===1/0)return;let r=(s.duration||0)+s.pauseDuration-(e-s.createdAt);if(r<0){s.visible&&K.dismiss(s.id);return}return setTimeout(()=>K.dismiss(s.id,t),r)});return()=>{a.forEach(e=>e&&clearTimeout(e))}},[s,r,t]);let l=(0,o.useCallback)(q(t),[t]),n=(0,o.useCallback)(()=>{l({type:5,time:Date.now()})},[l]),c=(0,o.useCallback)((e,t)=>{l({type:1,toast:{id:e,height:t}})},[l]),d=(0,o.useCallback)(()=>{r&&l({type:6,time:Date.now()})},[r,l]),u=(0,o.useCallback)((e,t)=>{let{reverseOrder:r=!1,gutter:a=8,defaultPosition:i}=t||{},o=s.filter(t=>(t.position||i)===(e.position||i)&&t.height),l=o.findIndex(t=>t.id===e.id),n=o.filter((e,t)=>t<l&&e.visible).length;return o.filter(e=>e.visible).slice(...r?[n+1]:[0,n]).reduce((e,t)=>e+(t.height||0)+a,0)},[s]);return(0,o.useEffect)(()=>{s.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=a.get(e.id);t&&(clearTimeout(t),a.delete(e.id))}})},[s,i]),{toasts:s,handlers:{updateHeight:c,startPause:n,endPause:d,calculateOffset:u}}})(s,i);return o.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...l},className:n,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(s=>{let i,l,n=s.position||t,c=d.calculateOffset(s,{reverseOrder:e,gutter:r,defaultPosition:t}),u=(i=n.includes("top"),l=n.includes("center")?{justifyContent:"center"}:n.includes("right")?{justifyContent:"flex-end"}:{},{left:0,right:0,display:"flex",position:"absolute",transition:D()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${c*(i?1:-1)}px)`,...i?{top:0}:{bottom:0},...l});return o.createElement(ex,{id:s.id,key:s.id,onHeightUpdate:d.updateHeight,className:s.visible?em:"",style:u},"custom"===s.type?O(s.message,s):a?a(s):o.createElement(ep,{toast:s,position:n}))}))};function ef(){let e=(0,l.useParams)(),t=(0,l.useRouter)(),s=e.slug,{addToCart:r,getItemQuantity:p,updateQuantity:w}=(0,b.useCart)(),[N,k]=(0,o.useState)(null),[C,F]=(0,o.useState)([]),[_,L]=(0,o.useState)([]),[E,P]=(0,o.useState)(!0),[z,$]=(0,o.useState)(null),[S,M]=(0,o.useState)(0),[O,A]=(0,o.useState)(!1),[D,B]=(0,o.useState)({x:0,y:0});(0,o.useEffect)(()=>{s&&I()},[s]);let I=async()=>{P(!0),$(null),F([]);try{let e=await g.api.products.getDetails(s);if(e.success&&e.data?.product){let t=e.data.product;if(k(t),await T(t.id),t.categories?.length>0)try{let e=await g.api.categories.getAll(),s=e?.data||e?.categories||[],r=[];t.categories.forEach(e=>{if(e.parent_category_id){let t=s.find(t=>String(t.id)===String(e.parent_category_id));t&&!r.find(e=>e.id===t.id)&&r.push({...t,isParent:!0})}r.find(t=>t.id===e.id)||r.push({...e,isParent:!1})}),L(r)}catch(e){L(t.categories.map(e=>({...e,isParent:!1})))}}else $("Product not found")}catch(e){console.error("Product fetch error:",e),$("Failed to load product")}finally{P(!1)}},T=async e=>{try{let t=await g.api.products.getRelatedProducts(e);t.success&&t.data&&F(t.data)}catch(e){console.error("Related products fetch error:",e)}};if(E)return(0,a.jsx)("div",{className:"min-h-screen flex items-center justify-center bg-gray-50",children:(0,a.jsxs)("div",{className:"text-center",children:[(0,a.jsx)("div",{className:"w-16 h-16 border-4 border-[#FF5533] border-t-transparent rounded-full animate-spin mx-auto mb-4"}),(0,a.jsx)("p",{className:"text-gray-600",children:"Loading product..."})]})});if(z||!N)return(0,a.jsxs)("div",{className:"min-h-screen flex flex-col items-center justify-center px-4 bg-gray-50",children:[(0,a.jsx)("p",{className:"text-red-600 mb-4 text-lg",children:z||"Product not found"}),(0,a.jsx)("button",{onClick:()=>t.push("/"),className:"px-6 py-3 bg-[#FF5533] text-white rounded-lg hover:bg-[#e64e27] transition-colors cursor-pointer",children:"Back to Home"})]});let R=parseFloat(N.sale_price||"0"),H=parseFloat(N.promotional_price||"0"),W=H>0&&H<R,U=W?H:R,q=N.gallery_images?N.gallery_images.split(",").map(e=>e.trim()).filter(e=>e.length>0):[],V=[...new Set([N.image,...q].filter(e=>e&&e.length>0))],Z=p(N.id);return(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 bg-gray-50 min-h-screen pb-20 md:pb-8",children:[(0,a.jsx)(i.default,{id:"86005101c80e7b06",children:".scrollbar-hide.jsx-86005101c80e7b06::-webkit-scrollbar{display:none}.scrollbar-hide.jsx-86005101c80e7b06{-ms-overflow-style:none;scrollbar-width:none}"}),(0,a.jsx)(eh,{position:"top-center",reverseOrder:!1,toastOptions:{duration:2e3,style:{background:"#fff",color:"#363636",fontSize:"14px",fontWeight:"500",padding:"12px 20px",borderRadius:"12px",boxShadow:"0 4px 12px rgba(0,0,0,0.15)"},success:{style:{border:"2px solid #10b981"},iconTheme:{primary:"#10b981",secondary:"#fff"}},error:{style:{border:"2px solid #ef4444"},iconTheme:{primary:"#ef4444",secondary:"#fff"}}}}),(0,a.jsx)("div",{className:"jsx-86005101c80e7b06 bg-white shadow-sm sticky top-0 z-40",children:(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 max-w-7xl mx-auto px-4 py-3 flex justify-between items-center",children:[(0,a.jsx)("button",{onClick:()=>t.back(),className:"jsx-86005101c80e7b06 p-2 hover:bg-gray-100 rounded-full cursor-pointer transition-colors text-gray-900",children:(0,a.jsx)(d.ChevronLeft,{size:24})}),(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 flex items-center gap-1 text-sm text-gray-600 mx-4 flex-1",children:[(0,a.jsx)(c.default,{href:"/",className:"hover:text-orange-500 transition-colors duration-200 whitespace-nowrap",children:"Home"}),(0,a.jsx)("svg",{fill:"none",stroke:"currentColor",strokeWidth:2,viewBox:"0 0 24 24",className:"jsx-86005101c80e7b06 w-3 h-3 text-gray-400 shrink-0",children:(0,a.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M9 5l7 7-7 7",className:"jsx-86005101c80e7b06"})}),(0,a.jsx)("span",{className:"jsx-86005101c80e7b06 font-semibold text-gray-800 truncate",children:N?.product_name})]}),(0,a.jsx)("button",{onClick:()=>{navigator.clipboard&&navigator.clipboard.writeText(window.location.href).then(()=>K.success("Link copied to clipboard!",{icon:"🔗",duration:2e3})).catch(()=>K.error("Failed to copy link",{duration:2e3}))},className:"jsx-86005101c80e7b06 p-2 hover:bg-gray-100 rounded-full cursor-pointer transition-colors text-gray-900",children:(0,a.jsx)(h,{size:20})})]})}),(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 max-w-7xl mx-auto px-4 py-6",children:[(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 grid grid-cols-1 lg:grid-cols-2 gap-8",children:[(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 space-y-4",children:[(0,a.jsxs)("div",{onMouseEnter:()=>A(!0),onMouseLeave:()=>A(!1),onMouseMove:e=>{if(!O)return;let t=e.currentTarget.getBoundingClientRect();B({x:(e.clientX-t.left)/t.width*100,y:(e.clientY-t.top)/t.height*100})},className:"jsx-86005101c80e7b06 bg-white rounded-xl border border-gray-200 p-4 relative aspect-square overflow-hidden cursor-zoom-in",children:[(0,a.jsx)("div",{className:"jsx-86005101c80e7b06 relative w-full h-full",children:(0,a.jsx)(n.default,{src:(0,g.getImageUrl)(V[S],"full"),alt:N.product_name,fill:!0,sizes:"(max-width: 768px) 100vw, 50vw",className:"object-contain transition-transform duration-300",style:O?{transform:"scale(2)",transformOrigin:`${D.x}% ${D.y}%`}:{},priority:!0})}),O&&(0,a.jsx)("div",{className:"jsx-86005101c80e7b06 absolute top-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-sm z-10",children:"Zoomed 2x"})]}),V.length>1&&(0,a.jsx)("div",{className:"jsx-86005101c80e7b06 flex gap-3 overflow-x-auto p-2 scrollbar-hide",children:V.map((e,t)=>(0,a.jsx)("button",{onClick:()=>M(t),className:`jsx-86005101c80e7b06 flex-shrink-0 w-20 h-20 rounded-xl bg-white border-2 transition-all cursor-pointer overflow-hidden ${t===S?"border-[#FF5533] shadow-lg scale-105":"border-gray-200 hover:border-gray-300"}`,children:(0,a.jsx)("div",{className:"jsx-86005101c80e7b06 relative w-full h-full p-2",children:(0,a.jsx)(n.default,{src:(0,g.getImageUrl)(e,"thumbnail"),alt:`Image ${t+1}`,fill:!0,className:"object-contain"})})},t))})]}),(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 space-y-6",children:[(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 bg-white rounded-xl border border-gray-200 p-6 space-y-4",children:[(0,a.jsx)("h1",{className:"jsx-86005101c80e7b06 text-2xl lg:text-3xl font-bold text-gray-900 leading-tight",children:N.product_name}),(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 flex items-baseline gap-3 pb-4 border-b border-gray-100",children:[(0,a.jsxs)("span",{className:"jsx-86005101c80e7b06 text-4xl font-bold text-[#FF5533]",children:["৳",Math.round(U)]}),W&&(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("span",{className:"jsx-86005101c80e7b06 text-2xl text-gray-400 line-through",children:["৳",Math.round(R)]}),(0,a.jsxs)("span",{className:"jsx-86005101c80e7b06 px-3 py-1 bg-red-100 text-red-600 text-sm font-bold rounded-full",children:[Math.round((R-H)/R*100),"% OFF"]})]})]}),N.short_description&&(0,a.jsx)("div",{className:"jsx-86005101c80e7b06 text-gray-600 leading-relaxed",children:N.short_description}),(0,a.jsx)("div",{className:"jsx-86005101c80e7b06 pt-4",children:0===Z?(0,a.jsxs)("button",{onClick:()=>{if(!N)return;let e=parseFloat(N.sale_price||"0"),t=parseFloat(N.promotional_price||"0"),s=p(N.id);s>0?w(N.id,s+1):r({product_id:N.id,name:N.product_name,price:t>0&&t<e?t:e,image:N.image,slug:N.slug},1)},className:"jsx-86005101c80e7b06 w-full md:w-auto px-8 py-3 bg-[#FF5533] hover:bg-[#e64e27] text-white font-bold text-lg rounded-full transition-all duration-300 flex items-center justify-center gap-3 cursor-pointer active:scale-95 shadow-lg hover:shadow-xl",children:[(0,a.jsx)(f.ShoppingCart,{size:20}),"Add to Cart"]}):(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 flex items-center w-full md:w-48 bg-[#FF5533] rounded-full overflow-hidden shadow-lg",children:[(0,a.jsx)("button",{onClick:()=>w(N.id,Z-1),className:"jsx-86005101c80e7b06 flex-1 flex justify-center items-center py-3 hover:bg-[#e64e27] transition-colors cursor-pointer",children:(0,a.jsx)(x,{size:20,className:"text-white"})}),(0,a.jsx)("span",{className:"jsx-86005101c80e7b06 flex-1 flex justify-center items-center py-3 text-white font-bold text-xl border-x border-white",children:Z}),(0,a.jsx)("button",{onClick:()=>w(N.id,Z+1),className:"jsx-86005101c80e7b06 flex-1 flex justify-center items-center py-3 hover:bg-[#e64e27] transition-colors cursor-pointer",children:(0,a.jsx)(m.Plus,{size:20,className:"text-white"})})]})}),(N.brand?.brand_name||_.length>0)&&(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 flex flex-col gap-1.5",children:[_.length>0&&(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 flex flex-wrap items-center gap-1.5",children:[(0,a.jsx)("span",{className:"jsx-86005101c80e7b06 text-[11px] font-semibold text-gray-500 mr-1",children:"Categories:"}),_.map(e=>(0,a.jsxs)(c.default,{href:`/category/${e.slug}`,className:`inline-flex items-center gap-1 px-2.5 py-0.5 border text-[11px] font-medium rounded-full transition-colors ${e.isParent?"bg-blue-50 border-blue-200 text-blue-600 hover:bg-blue-100":"bg-gray-100 border-gray-200 text-gray-600 hover:bg-gray-200"}`,children:[e.isParent?"🗂️":"📂"," ",e.category_name]},e.id))]}),N.brand?.brand_name&&(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 flex flex-wrap items-center gap-1.5",children:[(0,a.jsx)("span",{className:"jsx-86005101c80e7b06 text-[11px] font-semibold text-gray-500 mr-1",children:"Brand:"}),(0,a.jsxs)(c.default,{href:`/popular-brands/${N.brand.slug}`,className:"inline-flex items-center gap-1 px-2.5 py-0.5 bg-orange-50 border border-orange-200 text-[#FF5533] text-[11px] font-semibold rounded-full hover:bg-orange-100 transition-colors",children:["🏷️ ",N.brand.brand_name]})]})]})]}),N.description&&(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 bg-white rounded-xl border border-gray-200 p-6",children:[(0,a.jsx)("h2",{className:"jsx-86005101c80e7b06 text-xl font-bold text-gray-900 mb-4",children:"Product Description"}),(0,a.jsx)("div",{dangerouslySetInnerHTML:{__html:N.description},className:"jsx-86005101c80e7b06 text-gray-700 leading-relaxed prose prose-sm max-w-none prose-headings:text-gray-900 prose-p:text-gray-700 prose-ul:text-gray-700 prose-li:text-gray-700"})]})]})]}),C.length>0&&(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 px-4 mt-12",children:[(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 flex items-center justify-between mb-4",children:[(0,a.jsx)("h2",{className:"jsx-86005101c80e7b06 text-xl sm:text-2xl font-bold text-gray-900",children:"Related Products"}),(0,a.jsxs)("span",{className:"jsx-86005101c80e7b06 text-sm text-gray-500",children:[C.length," ",1===C.length?"product":"products"]})]}),(0,a.jsxs)("div",{className:"jsx-86005101c80e7b06 relative",children:[(0,a.jsx)("button",{className:"jsx-86005101c80e7b06 swiper-button-prev-related absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-[#319F00] hover:bg-green-500 rounded-full p-2 shadow-md transition-all cursor-pointer",children:(0,a.jsx)(d.ChevronLeft,{size:20,className:"text-gray-100"})}),(0,a.jsx)(j.Swiper,{modules:[v.Navigation],spaceBetween:12,slidesPerView:2,navigation:{prevEl:".swiper-button-prev-related",nextEl:".swiper-button-next-related"},breakpoints:{640:{slidesPerView:2,spaceBetween:12},768:{slidesPerView:4,spaceBetween:12},1024:{slidesPerView:6,spaceBetween:12}},className:"product-slider px-8",children:C.map(e=>(0,a.jsx)(j.SwiperSlide,{children:(0,a.jsx)(y.default,{product:e})},e.id))}),(0,a.jsx)("button",{className:"jsx-86005101c80e7b06 swiper-button-next-related absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-[#319F00] hover:bg-green-500 rounded-full p-2 shadow-md transition-all cursor-pointer",children:(0,a.jsx)(u.ChevronRight,{size:20,className:"text-gray-100"})})]})]})]})]})}e.s(["default",()=>ef],7823)}]);