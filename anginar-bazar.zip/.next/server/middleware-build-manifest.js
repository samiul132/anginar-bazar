globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f1b4d49aa9e249c5.js",
    "static/chunks/b0025f9b4c9a284f.js",
    "static/chunks/ecef2a6275901125.js",
    "static/chunks/7d6514a90169e63d.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/turbopack-245a1a430ad600b7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];