module.exports=[46703,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_popular-brands_%5Bslug%5D_page_actions_459e8a38.js.map