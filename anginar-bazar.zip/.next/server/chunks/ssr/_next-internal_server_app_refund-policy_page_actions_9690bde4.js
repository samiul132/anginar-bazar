module.exports=[55339,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_refund-policy_page_actions_9690bde4.js.map