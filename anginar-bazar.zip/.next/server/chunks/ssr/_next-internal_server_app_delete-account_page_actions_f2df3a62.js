module.exports=[33152,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_delete-account_page_actions_f2df3a62.js.map