module.exports=[14709,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_brands_page_actions_f4601e3a.js.map