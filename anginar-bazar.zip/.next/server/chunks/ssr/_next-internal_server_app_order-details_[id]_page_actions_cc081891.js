module.exports=[44552,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_order-details_%5Bid%5D_page_actions_cc081891.js.map