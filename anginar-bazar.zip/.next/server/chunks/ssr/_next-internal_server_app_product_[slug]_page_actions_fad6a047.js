module.exports=[66429,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_product_%5Bslug%5D_page_actions_fad6a047.js.map