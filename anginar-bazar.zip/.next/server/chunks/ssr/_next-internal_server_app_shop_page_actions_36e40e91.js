module.exports=[54629,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_shop_page_actions_36e40e91.js.map