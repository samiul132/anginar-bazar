module.exports=[52744,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_download-app_page_actions_a5d92e48.js.map