module.exports=[81882,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_popular-items_page_actions_34a480b9.js.map