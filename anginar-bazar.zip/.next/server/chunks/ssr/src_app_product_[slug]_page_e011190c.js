module.exports=[43627,a=>{"use strict";let b,c;var d,e=a.i(87924),f=a.i(31626),g=a.i(72131),h=a.i(50944),i=a.i(71987),j=a.i(38246),k=a.i(13749),l=a.i(50522),m=a.i(70106);let n=(0,m.default)("minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);var o=a.i(15618);let p=(0,m.default)("share-2",[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]]);var q=a.i(38784),r=a.i(536),s=a.i(98890),t=a.i(88190),u=a.i(91858);a.i(9068);var v=a.i(54385);let w={data:""},x=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,y=/\/\*[^]*?\*\/|  +/g,z=/\n+/g,A=(a,b)=>{let c="",d="",e="";for(let f in a){let g=a[f];"@"==f[0]?"i"==f[1]?c=f+" "+g+";":d+="f"==f[1]?A(g,f):f+"{"+A(g,"k"==f[1]?"":b)+"}":"object"==typeof g?d+=A(g,b?b.replace(/([^,])+/g,a=>f.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,b=>/&/.test(b)?b.replace(/&/g,a):a?a+" "+b:b)):f):null!=g&&(f=/^--/.test(f)?f:f.replace(/[A-Z]/g,"-$&").toLowerCase(),e+=A.p?A.p(f,g):f+":"+g+";")}return c+(b&&e?b+"{"+e+"}":e)+d},B={},C=a=>{if("object"==typeof a){let b="";for(let c in a)b+=c+C(a[c]);return b}return a};function D(a){let b,c,d=this||{},e=a.call?a(d.p):a;return((a,b,c,d,e)=>{var f;let g=C(a),h=B[g]||(B[g]=(a=>{let b=0,c=11;for(;b<a.length;)c=101*c+a.charCodeAt(b++)>>>0;return"go"+c})(g));if(!B[h]){let b=g!==a?a:(a=>{let b,c,d=[{}];for(;b=x.exec(a.replace(y,""));)b[4]?d.shift():b[3]?(c=b[3].replace(z," ").trim(),d.unshift(d[0][c]=d[0][c]||{})):d[0][b[1]]=b[2].replace(z," ").trim();return d[0]})(a);B[h]=A(e?{["@keyframes "+h]:b}:b,c?"":"."+h)}let i=c&&B.g?B.g:null;return c&&(B.g=B[h]),f=B[h],i?b.data=b.data.replace(i,f):-1===b.data.indexOf(f)&&(b.data=d?f+b.data:b.data+f),h})(e.unshift?e.raw?(b=[].slice.call(arguments,1),c=d.p,e.reduce((a,d,e)=>{let f=b[e];if(f&&f.call){let a=f(c),b=a&&a.props&&a.props.className||/^go/.test(a)&&a;f=b?"."+b:a&&"object"==typeof a?a.props?"":A(a,""):!1===a?"":a}return a+d+(null==f?"":f)},"")):e.reduce((a,b)=>Object.assign(a,b&&b.call?b(d.p):b),{}):e,d.target||w,d.g,d.o,d.k)}D.bind({g:1});let E,F,G,H=D.bind({k:1});function I(a,b){let c=this||{};return function(){let d=arguments;function e(f,g){let h=Object.assign({},f),i=h.className||e.className;c.p=Object.assign({theme:F&&F()},h),c.o=/ *go\d+/.test(i),h.className=D.apply(c,d)+(i?" "+i:""),b&&(h.ref=g);let j=a;return a[0]&&(j=h.as||a,delete h.as),G&&j[0]&&G(h),E(j,h)}return b?b(e):e}}var J=(a,b)=>"function"==typeof a?a(b):a,K=(b=0,()=>(++b).toString()),L="default",M=(a,b)=>{let{toastLimit:c}=a.settings;switch(b.type){case 0:return{...a,toasts:[b.toast,...a.toasts].slice(0,c)};case 1:return{...a,toasts:a.toasts.map(a=>a.id===b.toast.id?{...a,...b.toast}:a)};case 2:let{toast:d}=b;return M(a,{type:+!!a.toasts.find(a=>a.id===d.id),toast:d});case 3:let{toastId:e}=b;return{...a,toasts:a.toasts.map(a=>a.id===e||void 0===e?{...a,dismissed:!0,visible:!1}:a)};case 4:return void 0===b.toastId?{...a,toasts:[]}:{...a,toasts:a.toasts.filter(a=>a.id!==b.toastId)};case 5:return{...a,pausedAt:b.time};case 6:let f=b.time-(a.pausedAt||0);return{...a,pausedAt:void 0,toasts:a.toasts.map(a=>({...a,pauseDuration:a.pauseDuration+f}))}}},N=[],O={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},P={},Q=(a,b=L)=>{P[b]=M(P[b]||O,a),N.forEach(([a,c])=>{a===b&&c(P[b])})},R=a=>Object.keys(P).forEach(b=>Q(a,b)),S=(a=L)=>b=>{Q(b,a)},T={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},U=a=>(b,c)=>{let d,e=((a,b="blank",c)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:b,ariaProps:{role:"status","aria-live":"polite"},message:a,pauseDuration:0,...c,id:(null==c?void 0:c.id)||K()}))(b,a,c);return S(e.toasterId||(d=e.id,Object.keys(P).find(a=>P[a].toasts.some(a=>a.id===d))))({type:2,toast:e}),e.id},V=(a,b)=>U("blank")(a,b);V.error=U("error"),V.success=U("success"),V.loading=U("loading"),V.custom=U("custom"),V.dismiss=(a,b)=>{let c={type:3,toastId:a};b?S(b)(c):R(c)},V.dismissAll=a=>V.dismiss(void 0,a),V.remove=(a,b)=>{let c={type:4,toastId:a};b?S(b)(c):R(c)},V.removeAll=a=>V.remove(void 0,a),V.promise=(a,b,c)=>{let d=V.loading(b.loading,{...c,...null==c?void 0:c.loading});return"function"==typeof a&&(a=a()),a.then(a=>{let e=b.success?J(b.success,a):void 0;return e?V.success(e,{id:d,...c,...null==c?void 0:c.success}):V.dismiss(d),a}).catch(a=>{let e=b.error?J(b.error,a):void 0;e?V.error(e,{id:d,...c,...null==c?void 0:c.error}):V.dismiss(d)}),a};var W=1e3,X=H`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,Y=H`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Z=H`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,$=I("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${X} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${Y} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${a=>a.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${Z} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,_=H`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,aa=I("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${a=>a.secondary||"#e0e0e0"};
  border-right-color: ${a=>a.primary||"#616161"};
  animation: ${_} 1s linear infinite;
`,ab=H`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,ac=H`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,ad=I("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${ab} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${ac} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${a=>a.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ae=I("div")`
  position: absolute;
`,af=I("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ag=H`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,ah=I("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ag} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,ai=({toast:a})=>{let{icon:b,type:c,iconTheme:d}=a;return void 0!==b?"string"==typeof b?g.createElement(ah,null,b):b:"blank"===c?null:g.createElement(af,null,g.createElement(aa,{...d}),"loading"!==c&&g.createElement(ae,null,"error"===c?g.createElement($,{...d}):g.createElement(ad,{...d})))},aj=I("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,ak=I("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,al=g.memo(({toast:a,position:b,style:d,children:e})=>{let f=a.height?((a,b)=>{let d=a.includes("top")?1:-1,[e,f]=c?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*d}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*d}%,-1px) scale(.6); opacity:0;}
`];return{animation:b?`${H(e)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${H(f)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(a.position||b||"top-center",a.visible):{opacity:0},h=g.createElement(ai,{toast:a}),i=g.createElement(ak,{...a.ariaProps},J(a.message,a));return g.createElement(aj,{className:a.className,style:{...f,...d,...a.style}},"function"==typeof e?e({icon:h,message:i}):g.createElement(g.Fragment,null,h,i))});d=g.createElement,A.p=void 0,E=d,F=void 0,G=void 0;var am=({id:a,className:b,style:c,onHeightUpdate:d,children:e})=>{let f=g.useCallback(b=>{if(b){let c=()=>{d(a,b.getBoundingClientRect().height)};c(),new MutationObserver(c).observe(b,{subtree:!0,childList:!0,characterData:!0})}},[a,d]);return g.createElement("div",{ref:f,className:b,style:c},e)},an=D`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ao=({reverseOrder:a,position:b="top-center",toastOptions:d,gutter:e,children:f,toasterId:h,containerStyle:i,containerClassName:j})=>{let{toasts:k,handlers:l}=((a,b="default")=>{let{toasts:c,pausedAt:d}=((a={},b=L)=>{let[c,d]=(0,g.useState)(P[b]||O),e=(0,g.useRef)(P[b]);(0,g.useEffect)(()=>(e.current!==P[b]&&d(P[b]),N.push([b,d]),()=>{let a=N.findIndex(([a])=>a===b);a>-1&&N.splice(a,1)}),[b]);let f=c.toasts.map(b=>{var c,d,e;return{...a,...a[b.type],...b,removeDelay:b.removeDelay||(null==(c=a[b.type])?void 0:c.removeDelay)||(null==a?void 0:a.removeDelay),duration:b.duration||(null==(d=a[b.type])?void 0:d.duration)||(null==a?void 0:a.duration)||T[b.type],style:{...a.style,...null==(e=a[b.type])?void 0:e.style,...b.style}}});return{...c,toasts:f}})(a,b),e=(0,g.useRef)(new Map).current,f=(0,g.useCallback)((a,b=W)=>{if(e.has(a))return;let c=setTimeout(()=>{e.delete(a),h({type:4,toastId:a})},b);e.set(a,c)},[]);(0,g.useEffect)(()=>{if(d)return;let a=Date.now(),e=c.map(c=>{if(c.duration===1/0)return;let d=(c.duration||0)+c.pauseDuration-(a-c.createdAt);if(d<0){c.visible&&V.dismiss(c.id);return}return setTimeout(()=>V.dismiss(c.id,b),d)});return()=>{e.forEach(a=>a&&clearTimeout(a))}},[c,d,b]);let h=(0,g.useCallback)(S(b),[b]),i=(0,g.useCallback)(()=>{h({type:5,time:Date.now()})},[h]),j=(0,g.useCallback)((a,b)=>{h({type:1,toast:{id:a,height:b}})},[h]),k=(0,g.useCallback)(()=>{d&&h({type:6,time:Date.now()})},[d,h]),l=(0,g.useCallback)((a,b)=>{let{reverseOrder:d=!1,gutter:e=8,defaultPosition:f}=b||{},g=c.filter(b=>(b.position||f)===(a.position||f)&&b.height),h=g.findIndex(b=>b.id===a.id),i=g.filter((a,b)=>b<h&&a.visible).length;return g.filter(a=>a.visible).slice(...d?[i+1]:[0,i]).reduce((a,b)=>a+(b.height||0)+e,0)},[c]);return(0,g.useEffect)(()=>{c.forEach(a=>{if(a.dismissed)f(a.id,a.removeDelay);else{let b=e.get(a.id);b&&(clearTimeout(b),e.delete(a.id))}})},[c,f]),{toasts:c,handlers:{updateHeight:j,startPause:i,endPause:k,calculateOffset:l}}})(d,h);return g.createElement("div",{"data-rht-toaster":h||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...i},className:j,onMouseEnter:l.startPause,onMouseLeave:l.endPause},k.map(d=>{let h,i,j=d.position||b,k=l.calculateOffset(d,{reverseOrder:a,gutter:e,defaultPosition:b}),m=(h=j.includes("top"),i=j.includes("center")?{justifyContent:"center"}:j.includes("right")?{justifyContent:"flex-end"}:{},{left:0,right:0,display:"flex",position:"absolute",transition:c?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${k*(h?1:-1)}px)`,...h?{top:0}:{bottom:0},...i});return g.createElement(am,{id:d.id,key:d.id,onHeightUpdate:l.updateHeight,className:d.visible?an:"",style:m},"custom"===d.type?J(d.message,d):f?f(d):g.createElement(al,{toast:d,position:j}))}))};function ap(){let a=(0,h.useParams)(),b=(0,h.useRouter)(),c=a.slug,{addToCart:d,getItemQuantity:m,updateQuantity:w}=(0,s.useCart)(),[x,y]=(0,g.useState)(null),[z,A]=(0,g.useState)([]),[B,C]=(0,g.useState)([]),[D,E]=(0,g.useState)(!0),[F,G]=(0,g.useState)(null),[H,I]=(0,g.useState)(0),[J,K]=(0,g.useState)(!1),[L,M]=(0,g.useState)({x:0,y:0});(0,g.useEffect)(()=>{c&&N()},[c]);let N=async()=>{E(!0),G(null),A([]);try{let a=await r.api.products.getDetails(c);if(a.success&&a.data?.product){let b=a.data.product;if(y(b),await O(b.id),b.categories?.length>0)try{let a=await r.api.categories.getAll(),c=a?.data||a?.categories||[],d=[];b.categories.forEach(a=>{if(a.parent_category_id){let b=c.find(b=>String(b.id)===String(a.parent_category_id));b&&!d.find(a=>a.id===b.id)&&d.push({...b,isParent:!0})}d.find(b=>b.id===a.id)||d.push({...a,isParent:!1})}),C(d)}catch(a){C(b.categories.map(a=>({...a,isParent:!1})))}}else G("Product not found")}catch(a){console.error("Product fetch error:",a),G("Failed to load product")}finally{E(!1)}},O=async a=>{try{let b=await r.api.products.getRelatedProducts(a);b.success&&b.data&&A(b.data)}catch(a){console.error("Related products fetch error:",a)}};if(D)return(0,e.jsx)("div",{className:"min-h-screen flex items-center justify-center bg-gray-50",children:(0,e.jsxs)("div",{className:"text-center",children:[(0,e.jsx)("div",{className:"w-16 h-16 border-4 border-[#FF5533] border-t-transparent rounded-full animate-spin mx-auto mb-4"}),(0,e.jsx)("p",{className:"text-gray-600",children:"Loading product..."})]})});if(F||!x)return(0,e.jsxs)("div",{className:"min-h-screen flex flex-col items-center justify-center px-4 bg-gray-50",children:[(0,e.jsx)("p",{className:"text-red-600 mb-4 text-lg",children:F||"Product not found"}),(0,e.jsx)("button",{onClick:()=>b.push("/"),className:"px-6 py-3 bg-[#FF5533] text-white rounded-lg hover:bg-[#e64e27] transition-colors cursor-pointer",children:"Back to Home"})]});let P=parseFloat(x.sale_price||"0"),Q=parseFloat(x.promotional_price||"0"),R=Q>0&&Q<P,S=R?Q:P,T=x.gallery_images?x.gallery_images.split(",").map(a=>a.trim()).filter(a=>a.length>0):[],U=[...new Set([x.image,...T].filter(a=>a&&a.length>0))],W=m(x.id);return(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 bg-gray-50 min-h-screen pb-20 md:pb-8",children:[(0,e.jsx)(f.default,{id:"86005101c80e7b06",children:".scrollbar-hide.jsx-86005101c80e7b06::-webkit-scrollbar{display:none}.scrollbar-hide.jsx-86005101c80e7b06{-ms-overflow-style:none;scrollbar-width:none}"}),(0,e.jsx)(ao,{position:"top-center",reverseOrder:!1,toastOptions:{duration:2e3,style:{background:"#fff",color:"#363636",fontSize:"14px",fontWeight:"500",padding:"12px 20px",borderRadius:"12px",boxShadow:"0 4px 12px rgba(0,0,0,0.15)"},success:{style:{border:"2px solid #10b981"},iconTheme:{primary:"#10b981",secondary:"#fff"}},error:{style:{border:"2px solid #ef4444"},iconTheme:{primary:"#ef4444",secondary:"#fff"}}}}),(0,e.jsx)("div",{className:"jsx-86005101c80e7b06 bg-white shadow-sm sticky top-0 z-40",children:(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 max-w-7xl mx-auto px-4 py-3 flex justify-between items-center",children:[(0,e.jsx)("button",{onClick:()=>b.back(),className:"jsx-86005101c80e7b06 p-2 hover:bg-gray-100 rounded-full cursor-pointer transition-colors text-gray-900",children:(0,e.jsx)(k.ChevronLeft,{size:24})}),(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 flex items-center gap-1 text-sm text-gray-600 mx-4 flex-1",children:[(0,e.jsx)(j.default,{href:"/",className:"hover:text-orange-500 transition-colors duration-200 whitespace-nowrap",children:"Home"}),(0,e.jsx)("svg",{fill:"none",stroke:"currentColor",strokeWidth:2,viewBox:"0 0 24 24",className:"jsx-86005101c80e7b06 w-3 h-3 text-gray-400 shrink-0",children:(0,e.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M9 5l7 7-7 7",className:"jsx-86005101c80e7b06"})}),(0,e.jsx)("span",{className:"jsx-86005101c80e7b06 font-semibold text-gray-800 truncate",children:x?.product_name})]}),(0,e.jsx)("button",{onClick:()=>{navigator.clipboard&&navigator.clipboard.writeText(window.location.href).then(()=>V.success("Link copied to clipboard!",{icon:"🔗",duration:2e3})).catch(()=>V.error("Failed to copy link",{duration:2e3}))},className:"jsx-86005101c80e7b06 p-2 hover:bg-gray-100 rounded-full cursor-pointer transition-colors text-gray-900",children:(0,e.jsx)(p,{size:20})})]})}),(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 max-w-7xl mx-auto px-4 py-6",children:[(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 grid grid-cols-1 lg:grid-cols-2 gap-8",children:[(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 space-y-4",children:[(0,e.jsxs)("div",{onMouseEnter:()=>K(!0),onMouseLeave:()=>K(!1),onMouseMove:a=>{if(!J)return;let b=a.currentTarget.getBoundingClientRect();M({x:(a.clientX-b.left)/b.width*100,y:(a.clientY-b.top)/b.height*100})},className:"jsx-86005101c80e7b06 bg-white rounded-xl border border-gray-200 p-4 relative aspect-square overflow-hidden cursor-zoom-in",children:[(0,e.jsx)("div",{className:"jsx-86005101c80e7b06 relative w-full h-full",children:(0,e.jsx)(i.default,{src:(0,r.getImageUrl)(U[H],"full"),alt:x.product_name,fill:!0,sizes:"(max-width: 768px) 100vw, 50vw",className:"object-contain transition-transform duration-300",style:J?{transform:"scale(2)",transformOrigin:`${L.x}% ${L.y}%`}:{},priority:!0})}),J&&(0,e.jsx)("div",{className:"jsx-86005101c80e7b06 absolute top-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-sm z-10",children:"Zoomed 2x"})]}),U.length>1&&(0,e.jsx)("div",{className:"jsx-86005101c80e7b06 flex gap-3 overflow-x-auto p-2 scrollbar-hide",children:U.map((a,b)=>(0,e.jsx)("button",{onClick:()=>I(b),className:`jsx-86005101c80e7b06 flex-shrink-0 w-20 h-20 rounded-xl bg-white border-2 transition-all cursor-pointer overflow-hidden ${b===H?"border-[#FF5533] shadow-lg scale-105":"border-gray-200 hover:border-gray-300"}`,children:(0,e.jsx)("div",{className:"jsx-86005101c80e7b06 relative w-full h-full p-2",children:(0,e.jsx)(i.default,{src:(0,r.getImageUrl)(a,"thumbnail"),alt:`Image ${b+1}`,fill:!0,className:"object-contain"})})},b))})]}),(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 space-y-6",children:[(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 bg-white rounded-xl border border-gray-200 p-6 space-y-4",children:[(0,e.jsx)("h1",{className:"jsx-86005101c80e7b06 text-2xl lg:text-3xl font-bold text-gray-900 leading-tight",children:x.product_name}),(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 flex items-baseline gap-3 pb-4 border-b border-gray-100",children:[(0,e.jsxs)("span",{className:"jsx-86005101c80e7b06 text-4xl font-bold text-[#FF5533]",children:["৳",Math.round(S)]}),R&&(0,e.jsxs)(e.Fragment,{children:[(0,e.jsxs)("span",{className:"jsx-86005101c80e7b06 text-2xl text-gray-400 line-through",children:["৳",Math.round(P)]}),(0,e.jsxs)("span",{className:"jsx-86005101c80e7b06 px-3 py-1 bg-red-100 text-red-600 text-sm font-bold rounded-full",children:[Math.round((P-Q)/P*100),"% OFF"]})]})]}),x.short_description&&(0,e.jsx)("div",{className:"jsx-86005101c80e7b06 text-gray-600 leading-relaxed",children:x.short_description}),(0,e.jsx)("div",{className:"jsx-86005101c80e7b06 pt-4",children:0===W?(0,e.jsxs)("button",{onClick:()=>{if(!x)return;let a=parseFloat(x.sale_price||"0"),b=parseFloat(x.promotional_price||"0"),c=m(x.id);c>0?w(x.id,c+1):d({product_id:x.id,name:x.product_name,price:b>0&&b<a?b:a,image:x.image,slug:x.slug},1)},className:"jsx-86005101c80e7b06 w-full md:w-auto px-8 py-3 bg-[#FF5533] hover:bg-[#e64e27] text-white font-bold text-lg rounded-full transition-all duration-300 flex items-center justify-center gap-3 cursor-pointer active:scale-95 shadow-lg hover:shadow-xl",children:[(0,e.jsx)(q.ShoppingCart,{size:20}),"Add to Cart"]}):(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 flex items-center w-full md:w-48 bg-[#FF5533] rounded-full overflow-hidden shadow-lg",children:[(0,e.jsx)("button",{onClick:()=>w(x.id,W-1),className:"jsx-86005101c80e7b06 flex-1 flex justify-center items-center py-3 hover:bg-[#e64e27] transition-colors cursor-pointer",children:(0,e.jsx)(n,{size:20,className:"text-white"})}),(0,e.jsx)("span",{className:"jsx-86005101c80e7b06 flex-1 flex justify-center items-center py-3 text-white font-bold text-xl border-x border-white",children:W}),(0,e.jsx)("button",{onClick:()=>w(x.id,W+1),className:"jsx-86005101c80e7b06 flex-1 flex justify-center items-center py-3 hover:bg-[#e64e27] transition-colors cursor-pointer",children:(0,e.jsx)(o.Plus,{size:20,className:"text-white"})})]})}),(x.brand?.brand_name||B.length>0)&&(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 flex flex-col gap-1.5",children:[B.length>0&&(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 flex flex-wrap items-center gap-1.5",children:[(0,e.jsx)("span",{className:"jsx-86005101c80e7b06 text-[11px] font-semibold text-gray-500 mr-1",children:"Categories:"}),B.map(a=>(0,e.jsxs)(j.default,{href:`/category/${a.slug}`,className:`inline-flex items-center gap-1 px-2.5 py-0.5 border text-[11px] font-medium rounded-full transition-colors ${a.isParent?"bg-blue-50 border-blue-200 text-blue-600 hover:bg-blue-100":"bg-gray-100 border-gray-200 text-gray-600 hover:bg-gray-200"}`,children:[a.isParent?"🗂️":"📂"," ",a.category_name]},a.id))]}),x.brand?.brand_name&&(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 flex flex-wrap items-center gap-1.5",children:[(0,e.jsx)("span",{className:"jsx-86005101c80e7b06 text-[11px] font-semibold text-gray-500 mr-1",children:"Brand:"}),(0,e.jsxs)(j.default,{href:`/popular-brands/${x.brand.slug}`,className:"inline-flex items-center gap-1 px-2.5 py-0.5 bg-orange-50 border border-orange-200 text-[#FF5533] text-[11px] font-semibold rounded-full hover:bg-orange-100 transition-colors",children:["🏷️ ",x.brand.brand_name]})]})]})]}),x.description&&(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 bg-white rounded-xl border border-gray-200 p-6",children:[(0,e.jsx)("h2",{className:"jsx-86005101c80e7b06 text-xl font-bold text-gray-900 mb-4",children:"Product Description"}),(0,e.jsx)("div",{dangerouslySetInnerHTML:{__html:x.description},className:"jsx-86005101c80e7b06 text-gray-700 leading-relaxed prose prose-sm max-w-none prose-headings:text-gray-900 prose-p:text-gray-700 prose-ul:text-gray-700 prose-li:text-gray-700"})]})]})]}),z.length>0&&(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 px-4 mt-12",children:[(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 flex items-center justify-between mb-4",children:[(0,e.jsx)("h2",{className:"jsx-86005101c80e7b06 text-xl sm:text-2xl font-bold text-gray-900",children:"Related Products"}),(0,e.jsxs)("span",{className:"jsx-86005101c80e7b06 text-sm text-gray-500",children:[z.length," ",1===z.length?"product":"products"]})]}),(0,e.jsxs)("div",{className:"jsx-86005101c80e7b06 relative",children:[(0,e.jsx)("button",{className:"jsx-86005101c80e7b06 swiper-button-prev-related absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-[#319F00] hover:bg-green-500 rounded-full p-2 shadow-md transition-all cursor-pointer",children:(0,e.jsx)(k.ChevronLeft,{size:20,className:"text-gray-100"})}),(0,e.jsx)(u.Swiper,{modules:[v.Navigation],spaceBetween:12,slidesPerView:2,navigation:{prevEl:".swiper-button-prev-related",nextEl:".swiper-button-next-related"},breakpoints:{640:{slidesPerView:2,spaceBetween:12},768:{slidesPerView:4,spaceBetween:12},1024:{slidesPerView:6,spaceBetween:12}},className:"product-slider px-8",children:z.map(a=>(0,e.jsx)(u.SwiperSlide,{children:(0,e.jsx)(t.default,{product:a})},a.id))}),(0,e.jsx)("button",{className:"jsx-86005101c80e7b06 swiper-button-next-related absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-[#319F00] hover:bg-green-500 rounded-full p-2 shadow-md transition-all cursor-pointer",children:(0,e.jsx)(l.ChevronRight,{size:20,className:"text-gray-100"})})]})]})]})]})}a.s(["default",()=>ap],43627)}];

//# sourceMappingURL=src_app_product_%5Bslug%5D_page_e011190c.js.map