1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[19622,["/_next/static/chunks/c6f585d75fa067e0.js","/_next/static/chunks/60e320e0fcc93536.js","/_next/static/chunks/88e68a97c4d701c1.js","/_next/static/chunks/a43bb9413dbf5092.js"],"default"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
0:{"buildId":"X1kkzPnJEuZ6yrtMcXG8G","rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","div",null,{"className":"min-h-screen flex items-center justify-center","children":"Loading..."}],"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/a43bb9413dbf5092.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
