1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"X1kkzPnJEuZ6yrtMcXG8G","rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;https://play.google.com/store/apps/details?id=com.designcodeit.anginarbazar;307;"}
