:HL["/_next/static/chunks/620c5c9308396e23.css","style"]
0:{"buildId":"X1kkzPnJEuZ6yrtMcXG8G","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
